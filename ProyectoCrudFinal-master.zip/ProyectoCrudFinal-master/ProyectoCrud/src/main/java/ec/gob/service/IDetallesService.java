package ec.gob.service;

import ec.gob.model.Detalle;

public interface IDetallesService {
void insertar(Detalle detalle);
void eliminar(int detalle);
}
